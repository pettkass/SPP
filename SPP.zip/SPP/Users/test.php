<div class="details" style="display: inline-block;">
                                            <div class="col col-md-3"><label for="text-input" class=" form-control-label" style="display: inline-block;">Parking Number</label></div>
                                            <div class="col-12 col-md-9" > <select name="parkingno" id="parkingno" class="form-control" style="font-size:20px; border-width: 5px;margin-left: 20px; width: auto;">
                                                <option value="0">Available Slots</option><?php $query=mysqli_query($con,"select * from tblslots where Status='F'");
                                                  while($row=mysqli_fetch_array($query))
                                                  {
                                                  ?>    
                                                                                    <option value="<?php echo $row['VehicleCat'];?>"><?php echo $row['Label'];?></option>
                                                      <?php } ?> 
                                            </select>
                                         
                                                  </div>
                                          </div>