<?php
session_start();
error_reporting(0);
include('../Admin/includes/dbconnection.php');
if (strlen($_SESSION['vpmsaid']==0)) {
  header('location:logout.php');
  } else{

  }

if(isset($_POST['unpark'])){
  $vehreno=$_SESSION['vehid'];
  $status=  'OUT';
$remark='Vehicle is out';
$fee=50;
$label=$_SESSION['label'];
$userid=$_SESSION['vpmsaid'];
$query=mysqli_query($con, "select* from tblwallet where UserId='$userid'");
$ret=mysqli_fetch_array($query);
if ($ret) {
    $wbalance= $ret['Amount'];
    $newbalance=$wbalance - $fee;
    if($newbalance <=$fee){
      echo '<script>alert("Insufficient amount.Kindly top up.")</script>';
      echo "<script>window.location.href='topup.php'</script>";
    }
    $query1=mysqli_query($con, "update  tblwallet  set Amount='$newbalance' where UserId='$userid'");
    $query1=mysqli_query($con, "update  tblslots  set Status='F' where Label='$label'");
    $query2=mysqli_query($con, "update tblvehicle set Remark='$remark',Status='$status',ParkingCharge='$fee' where  Code='$vehreno'");
    if ($query2) {
    echo '<script>alert("Vehicle has been Unparked.Thankyou")</script>';
    echo "<script>window.location.href='dashboard.php'</script>";
  }
  else
    {
      echo '<script>alert("Something Went Wrong. Please try again")</script>';
    }

}
else
{
  echo '<script>alert("Something Went Wrong. Please try again")</script>';
}
 
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../Admin/Assets/style.css">
    <title>Unpark Vehicle</title>
</head>
<body>
<body class="body">
   <div class="regform" style="margin-top: 50px;margin-left: 30%;background-color: aliceblue;width:500px">
   <div style="background-color:green;">
   <div align="center" style="border-radius: 50%;background-color: white;width: 120px;margin-left: 40%;padding: 5px;">
            <h1>UnPark Vehicle</h1>
        </div> 
   </div> 
   <form action="" class="form" method="post" >
       
        <?php
$vehreno=$_SESSION['vehid'];
$ret=mysqli_query($con,"select * from tblvehicle where Code='$vehreno'&&Status='IN'");
$cnt=1;
while ($row=mysqli_fetch_array($ret)){

    ?>
                                           
                                           <div class="details" style="display: inline-block;">
                                            <div class="col col-md-3"><label for="text-input" class=" form-control-label" style="display: inline-block;">Parking Number</label></div>
                                            <div class="col-12 col-md-9"><input class=" form-control" id="parkingno" name="parkingno" type="text" value="<?php  echo $row['ParkingNumber'];?>"></div>
                                          </div>
                                           <div class="details" style="display: inline-block;">
                                            <div class="col col-md-3"><label for="text-input" class=" form-control-label" style="display: inline-block;">Vehicle Color</label></div>
                                            <div class="col-12 col-md-9"><input class=" form-control" id="vehcomp" name="vehcomp" type="text" value="<?php  echo $row['VehicleColor'];?>"></div>
                                          </div>
                                          <div class="details" style="display: inline-block;">
                                            <div class="col col-md-3"><label for="email-input" class=" form-control-label">Registration Number</label></div>
                                            <div class="col-12 col-md-9"><input class=" form-control" id="vehreno" name="vehreno" type="text" value="<?php  echo $row['RegistrationNumber'];?>"  required='true'></div>
                                          </div>
                                           <div class="details" style="display: inline-block;" >
                                            <div class="col col-md-3"><label for="password-input" class=" form-control-label">Owner Name</label></div>
                                            <div class="col-12 col-md-9"> <input class="form-control " id="ownername" name="ownername" type="text" value="<?php  echo $row['OwnerName'];?>" required="true"></div>
                                          </div>
                                         <div class="details">
                                            <div class="col col-md-3"><label for="disabled-input" class=" form-control-label">Owner Contact Number</label></div>
                                            <div class="col-12 col-md-9"><input class="form-control " id="ownercontno" name="ownercontno" type="ownercontno" value="<?php  echo $row['OwnerContactNumber'];?>" required="true" ></div>
                                        </div>
                                        <div class="details" style="width:auto;">
                                            <div class="col-12 col-md-9"><button type="submit" class="btn btn-primary btn-sm" name="unpark" >UnPark</button></div>
                                        </div>
                                        
                                        <?php } ?>
        
    </form>
   </div>
   <?php include('dashboard.php') ?>
</body>
</html>