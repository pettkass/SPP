<?php
session_start();
error_reporting(0);
include('../Admin/includes/dbconnection.php');

if(isset($_POST['reset']))
  {
    $email=$_POST['email'];
    $phone=$_POST['phone'];
    $query=mysqli_query($con,"select ID from users where  Email='$email' && MobileNumber='$phone' ");
    $ret=mysqli_fetch_array($query);
    if($ret>0){
        $_SESSION['vpmsaid']=$ret['ID'];
        $_SESSION['phone']=$phone;
      $_SESSION['email']=$email;
     header('location:reset.php');
    }
    else{
  
     echo "<script>alert('Invalid Details.');</script>";
    }
  }
  ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
 
    <title>User forgot Password</title>
  </head>
<body>
    <div class="regform"  style="margin-top: 50px;margin-left: 30%;background-color: aliceblue;width:400px">
    <div style="background-color:green;">
      <div align="center" style="border-radius: 50%;background-color: white;width: 135px;margin-left: 35%;padding: 5px;">
            <h1>Forgot Password</h1>
        </div>  
</div>  
    <form   method="post" class="form" style="margin-top: 20px;">
            <div  style="margin-left: 5%;font-size:24px;margin-top: 5px;">
                <label for="">Email</label>
                <input style="width:290px;padding-left:10px;font-size:20px;height:25px;" type="email" placeholder="Enter Email" id="password" name="email" type="email" placeholder="Email" name="email"  required>
            </div>
            <div  style="margin-left: 5%;font-size:24px;margin-top: 5px;">
                <label for="">Mobile N0.</label>
                <input  style="width:240px;padding-left:10px;font-size:20px;height:25px;" type="text" placeholder="Enter Mobile Number" id="password" name="phone"type="text" placeholder="Mobile Number" id="phone" name="phone"   required>
            </div>
            <div class="alternative" style="display:inline-block;">
                <li style="display: inline-block;margin-left: 35px;font-size: 20px; font-weight: bold;background-color: green;border-radius: 5px;margin-top:5px"><a href="Registration.php" style="color: black;">New User?</a></li>
                <li style="display: inline-block;margin-left: 35px;font-size: 20px; font-weight: bold;background-color: green;border-radius: 5px;margin-top:5px"><a href="login.php" style="color: black;">sign in</a></li>
            <div class="details" >
                <button  style="width:300px;font-size:26px;height:30px;border-radius: 50px;margin-top: 5px;margin-left: 15%;background-color:blue;" type="submit" name="reset">Reset Pasword</button>
            </div>
        </form>
       </div>
</body>
</html>