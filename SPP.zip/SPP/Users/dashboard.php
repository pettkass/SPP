<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['vpmsaid']==0)) {
  header('location:logout.php');
  }

  ?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../admin/Assets/style.css">
    <title>Users Dashboard</title>
</head>
<body class="body">
    <div style="background-color: green;width:auto;" class="adminheader">  
        <ul>
            <li><p style="font-size:19px;">Smart parking & traffic solution <img src="../Admin/images/user.png" alt=""></p></li>
            <li><a href="traffic.php">Navigation</a></li>
            <li><a href="park.php">Park Vehicle</a></li>
            <li><a href="unpark.php">Unpark Vehicle</a></li>
            <li><a href="profile.php">Profile</a></li>
            <li><a href="logout.php"><img src="../Admin/images/logout.png" alt="" style="margin-left: 0px;margin-top: 5px;width: 50px; height: 26px; border-radius: 5px;"></a></li>
        </ul>
    </div>
    
    <div  class="adminside" >
        <ul style="background-color: green;">
            <li><a ><img style="margin-top: 12px;" src="../Admin/images/wallet.png" alt="">Acc: 
                <?php
                session_start();
                error_reporting(0);
                include('../Admin/includes/dbconnection.php');
                $userid=$_SESSION['vpmsaid'];
                $query=mysqli_query($con, "select* from tblwallet where UserId='$userid'");
                $ret=mysqli_fetch_array($query);
                if ($ret) {
                    echo $ret['Amount'];
                }
                else
                {
                echo '<script>alert("Something Went Wrong. Please try again")</script>';

}?></a>
            </li><hr style="margin-left: -40px;">   
                                    

            <li><a href="unpark.php"><img src="../Admin/images/parking.png" alt="">Parking Details</a></li><hr style="margin-left: -40px;">
            <li><a href="print.php"><img src="../Admin/images/receipts.png" alt="">Receipts</a></li>
        </ul>
    </div><hr style="width: auto;height: 10px;background: rgb(20, 20, 20);margin-left: -1px;">

    <div class="middle">
        <div class="news" style="width:250px">
            <h1 style="color: black;font-weight: bold;font-style: italic;margin-left: 50px;">News</h1>
            <li>The rates per hour is ksh. 50</li>
            <li>No cash payments</li>
            <li>Business No:522522</li>
            <li>Accout No:1277528462</li>
        </div>
        <div class="History" style="width:290px;margin-left:300px">
            <h1 style="color: black;font-weight: bold;font-style: italic;margin-left: 50px;font-size:28px">Parking History</h1>
            <a style="margin-left: 25px;text-decoration:none;"href="bwdatereport.php"> Your Parking History</a>
        </div>
        <div class="action" style="width:340px;margin-left:620px">
            <h1 style="color: black;font-weight: bold;font-style: italic;margin-left: 50px;" >Actions</h1>
            <a style="margin-left: 15px;text-decoration:none;"href="park.php"> Park</a>
            <a style="margin-left: 15px;text-decoration:none;" href="unpark.php"> UnPark</a>
            <a style="margin-left: 15px;text-decoration:none;" href="topup.php"> Top up Wallet</a>
        </div>

    </div>
   </body>
</html>