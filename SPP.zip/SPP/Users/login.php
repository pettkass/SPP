<?php
session_start();
error_reporting(0);
include('../Admin/includes/dbconnection.php');

if(isset($_POST['login']))
  {
    $email=$_POST['email'];
    $password=md5($_POST['password']);
    $query=mysqli_query($con,"select ID,MobileNumber from users where  Email='$email' && Password='$password' ");
    $ret=mysqli_fetch_array($query);
    if($ret>0){
        $_SESSION['vpmsaid']=$ret['ID'];
        $_SESSION['unique']=$ret['MobileNumber'];
     header('location:dashboard.php');
    }
    else{
  
     echo "<script>alert('Invalid Details.');</script>";
    }
  }
  ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Users Login</title>

</head>
<body>
    <style>
        
        @media (max-width: 626px) {
            .regform{
             margin-left: -100px;
        
            }
        }
    </style>

    <div class="regform" style="margin-top: 50px;margin-left: 30%;background-color: aliceblue;width:400px; @media (max-width: 626px) {margin-left: 15%; }">
     <div  style="background-color:green;">
         <div align="center" style="border-radius: 50%;background-color: white;width: 120px;margin-left: 35%;padding: 5px;">
            <h1>User Login</h1>
        </div> 
   </div>    
    <form   method="post" class="form" style="margin-top: 20px;">
            <div style="margin-left: 5%;margin-top: 5px;font-size:20px;" >
                <label for="">Email</label>
                <input style="width:290px;padding-left:10px;font-size:20px;height:25px;" type="email" placeholder="Enter Email" name="email"  required>
            </div>
            <div class="details" style="margin-left: 5%;font-size:20px;margin-top: 5px;">
                <label for="">Password</label>
                <input style="width:260px;padding-left:10px;font-size:20px;height:25px;" type="password" placeholder="Enter SPassword" id="password" name="password"   required>
            </div>
            <div class="alternative" style="display:inline-block;">
                <li style="display: inline-block;margin-left: 35px;font-size: 20px; font-weight: bold;background-color: green;border-radius: 5px;margin-top:5px"><a href="Registration.php" style="color: black;">New User?</a></li>
                <li style="display: inline-block;margin-left: 35px;font-size: 20px; font-weight: bold;text-decoration:none;border-radius: 5px;"><a href="forgotpassword.php" style="color: red;">Forgot Pasword?</a></li>
            <div class="details"style="margin-left: 5%;font-size:26px;margin-top: 5px;" >
                <button  style="width:300px;font-size:26px;height:30px;border-radius: 50px;margin-left: 15%;background-color:blue;" type="submit" name="login">Log in</button>
            </div>
        </form>
       </div>
</body>
</html>