<?php
session_start();
error_reporting(0);
include('../Admin/includes/dbconnection.php');

if(isset($_POST['park'])){
 $ucode=random_int(0,100000);
$parkingnumber=$_POST['parkingno'];
$vehcol=$_POST['vehcol'];
$vehreno=$_POST['vehreno'];
$ownername=$_POST['ownername'];
$ownercontno=$_POST['ownercontno'];
$status=  'IN';
$remark='Vehicle is in';
$query=mysqli_query($con, "insert into  tblvehicle(Code,ParkingNumber,VehicleColor,RegistrationNumber,OwnerName,OwnerContactNumber,Remark,Status) value('$ucode','$parkingnumber','$vehcol','$vehreno','$ownername','$ownercontno','$remark','$status')");
if ($query) {
  $query1=mysqli_query($con, "update  tblslots  set Status='O' where Label='$parkingnumber'");
echo "<script>alert('Vehicle has been Parked Successfuly');</script>";
echo "<script>window.location.href='unpark.php'</script>";
$_SESSION['vehid']=$ucode;
$_SESSION['label']=$parkingnumber;
}
else
{
 echo "<script>alert('Something Went Wrong. Please try again.');</script>";       
}
}
  ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
    <title>Park Vehicle</title>
</head>
<body>
<body class="body">

   <div class="regform" style="margin-top: 50px;margin-left: 30%;background-color: aliceblue;width:500px">
   <div style="background-color:green;">
   <div align="center" style="border-radius: 50%;background-color: white;width: 120px;margin-left: 40%;padding: 5px;">
            <h1>Park Vehicle</h1>
        </div> 
   </div>  
   <form action="" class="form" method="post" >
        <div class="details" style="display: inline-block;">
                                            <div class="col col-md-3"><label for="text-input" class=" form-control-label" style="display: inline-block;">Parking Number</label></div>
                                            <div class="col-12 col-md-9" > 
                                              <select  name="parkingno" id="parkingno" class="form-control" style="font-size:20px; border-width: 5px;border-color: black;margin-left: 10px; width: 180px;padding-left: 5px;">
                                                <option value="0" style="width: 200px;height:30px">Available Slots</option>
                                                <?php $query=mysqli_query($con,"select * from tblslots where Status='F'");
                                                  while($row=mysqli_fetch_array($query))
                                                  {
                                                    
                                                  ?>    
                                                                                    <option value="<?php echo $row['Label'];?>"><?php echo $row['Label']; ?></option>
                                                      <?php } ?> 
                                            </select>
                                         
                                                  </div>
                                          </div>
                            <?php
                    $adminid=$_SESSION['vpmsaid'];
                    $ret=mysqli_query($con,"select * from users where ID='$adminid'");
                    $cnt=1;
                    while ($row=mysqli_fetch_array($ret)){

                        ?>
                                                                                     
                                           <div class="details" style="display: inline-block;">
                                            <div class="col col-md-3"><label for="text-input" class=" form-control-label" style="display: inline-block;">Vehicle Color</label></div>
                                            <div class="col-12 col-md-9"><input style="width: 200px;" class=" form-control" id="vehcol" name="vehcol" type="text" required="true" ></div>
                                          </div>
                                          
                                          <div class="details" style="display: inline-block;">
                                            <div class="col col-md-3"><label for="email-input" class=" form-control-label">Registration Number</label></div>
                                            <div class="col-12 col-md-9"><input style="width: 200px;" class=" form-control" id="vehreno" name="vehreno" type="text" value="<?php  echo $row['RegistrationNumber'];?>"  required='true'>
                                          </div>
                                          </div>
                                           <div class="details"  style="display: inline-block;">
                                            <div class="col col-md-3"><label for="password-input" class=" form-control-label">Owner Name</label></div>
                                            <div class="col-12 col-md-9"> <input style="width: 200px;" class="form-control " id="ownername" name="ownername" type="text" value="<?php  echo $row['FirstName'] ; echo $row['LastName']; ?>" required="true"></div>
                                          </div>
                                         <div class="details">
                                            <div class="col col-md-3"><label for="disabled-input" class=" form-control-label">Owner Contact Number</label></div>
                                            <div class="col-12 col-md-9"><input style="width: 200px;" class="form-control " id="ownercontno" name="ownercontno" type="ownercontno" value="<?php  echo $row['MobileNumber'];?>" required="true" ></div>
                                        </div>
                                        <div class="details" style="width:auto;">
                                            <div class="col-12 col-md-9"><button type="submit" class="btn btn-primary btn-sm" name="park" >Park</button></div>
                                        </div>
                                          <?php } ?>
    </form>
   </div>
   <?php include('dashboard.php') ?>
</body>
</html>