<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['vpmsaid']==0)) {
  header('location:logout.php');
  }

  ?>
<?php include_once('dashboard.php');?>
<iframe style="margin-left:20%;margin-top:-61%;" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d280805.9741857178!2d36.53526839725354!3d-1.3379765202402047!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x182f1172d84d49a7%3A0xf7cf0254b297924c!2sNairobi!5e0!3m2!1sen!2ske!4v1709281040182!5m2!1sen!2ske" width="800" height="400" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
