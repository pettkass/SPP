<?php
session_start();
error_reporting(0);
include('../Admin/includes/dbconnection.php');
if (strlen($_SESSION['vpmsaid']==0)) {
  header('location:logout.php');
  } else{

  }

if(isset($_POST['add'])){
    $parkingnumber=mt_rand(100000000, 999999999);
    $catename=$_POST['catename'];
     $vehcomp=$_POST['vehcomp'];
    $vehreno=$_POST['vehreno'];
    $ownername=$_POST['ownername'];
    $ownercontno=$_POST['ownercontno'];
    $enteringtime=$_POST['enteringtime'];
     
$query=mysqli_query($con, "insert into  tblvehicle(ParkingNumber,VehicleCategory,VehicleCompanyname,RegistrationNumber,OwnerName,OwnerContactNumber) value('$parkingnumber','$catename','$vehcomp','$vehreno','$ownername','$ownercontno')");
if ($query) {
echo "<script>alert('Vehicle Entry Detail has been added');</script>"
}
else
{
 echo "<script>alert('Something Went Wrong. Please try again.');</script>";       
}
}
  ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../Admin/Assets/style.css">
    <title>Add Vehicle</title>
</head>
<body>
<body class="body">

   <div class="regform" style="margin-top: 50px;margin-left: 30%;">
    <form action="" class="form" method="post" >
        <h1 style="margin-left: 30px;">Vehicle Details </h1>
        <?php
$adminid=$_SESSION['vpmsaid'];
$ret=mysqli_query($con,"select * from tblvehicle where ID='$adminid'");
$cnt=1;
while ($row=mysqli_fetch_array($ret)){

    ?>
                                           
                                           <div class="details" style="display: inline-block;">
                                            <div class="col col-md-3"><label for="text-input" class=" form-control-label" style="display: inline-block;">Vehicle Company</label></div>
                                            <div class="col-12 col-md-9"><input class=" form-control" id="vehcomp" name="vehcomp" type="text" value="<?php  echo $row['VehicleCompanyname'];?>"></div>
                                          </div>
                                          <div class="details">
                                            <div class="col col-md-3"><label for="email-input" class=" form-control-label">Registration Number</label></div>
                                            <div class="col-12 col-md-9"><input class=" form-control" id="vehreno" name="vehreno" type="text" value="<?php  echo $row['RegistrationNumber'];?>"  required='true'></div>
                                          </div>
                                           <div class="details">
                                            <div class="col col-md-3"><label for="password-input" class=" form-control-label">Owner Name</label></div>
                                            <div class="col-12 col-md-9"> <input class="form-control " id="ownername" name="ownername" type="text" value="<?php  echo $row['OwnerName'];?>" required="true"></div>
                                          </div>
                                         <div class="details">
                                            <div class="col col-md-3"><label for="disabled-input" class=" form-control-label">Owner Contact Number</label></div>
                                            <div class="col-12 col-md-9"><input class="form-control " id="ownercontno" name="ownercontno" type="ownercontno" value="<?php  echo $row['OwnerContactNumber'];?>" required="true" ></div>
                                        </div>
                                        <div class="details" style="width:300px;">
                                            <div class="col-12 col-md-9"><button type="submit" class="btn btn-primary btn-sm" name="update" >Update</button></div>
                                        </div>
                                        <?php } ?>
        
    </form>
   </div>
   <?php include('dashboard.php') ?>
</body>
</html>