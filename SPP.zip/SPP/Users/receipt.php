<?php
session_start();
error_reporting(0);
include('../Admin/includes/dbconnection.php');
if (strlen($_SESSION['vpmsaid']==0)) {
    header('location:logout.php');
    } else{

    }
  
  ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../Admin/Assets/style.css">
    <title>Vehicle Receipts </title>
</head>
<body>
<body class="body">

   <div class="regform" style="margin-top: 50px;margin-left: 30%;background-color: aliceblue;width:500px">
</div>
   <?php include('dashboard.php') ?>
</body>
</html>