<?php
session_start();
error_reporting(0);
if (strlen($_SESSION['vpmsaid']==0)) {
  header('location:logout.php');
  } else{

  }

include('../Admin/includes/dbconnection.php');
    if(isset($_POST['update'])){
    $uid=$_SESSION['vpmsaid'];
    $fname=$_POST['firstname'];
    $lname=$_POST['lastname'];
    $phone=$_POST['phone'];
    $email=$_POST['email'];  
    
    $query=mysqli_query($con, "update users set FirstName='$fname', LastName='$lname', MobileNumber='$phone', Email='$email' where ID='$uid'");
    if ($query) {
    echo '<script>alert("User profile has been updated.")</script>';
  }
  else
    {
      echo '<script>alert("Something Went Wrong. Please try again")</script>';
    }
  }
  ?>
<!doctype html>
<html class="no-js" lang="">
<head>
    <title>User Profile</title>
    <link rel="stylesheet" href="../admin/Assets/style.css">
</head>
<body >
  <?php include('dashboard.php') ?>
    <div style="background-color: aliceblue;border-radius: 5px;margin-left: 30%;margin-top: -60%;width:500px;">
       <div style="background-color:green;">
        <div align="center" style="border-radius: 50%;background-color: white;width: 120px;margin-left: 40%;padding: 5px;">
            <h1>Profile Details</h1>
        </div> 
   </div>     
    <form  method="post" class="form"  style="diplay:inline-block;font-size:20px;">
            
            <?php
$adminid=$_SESSION['vpmsaid'];
$ret=mysqli_query($con,"select * from users where ID='$adminid'");
$cnt=1;
while ($row=mysqli_fetch_array($ret)){

    ?>
                                           <div class="details" style="display: inline-block;font-size:30px;">
                                            <div class="col col-md-3"><label for="text-input" class=" form-control-label" style="display: inline-block;">First Name</label></div>
                                            <div class="col-12 col-md-9"><input class=" form-control" id="adminname" name="firstname" type="text" value="<?php  echo $row['FirstName'];?>"></div>
                                          </div>
                                          <div class="details" style="display: inline-block;">
                                            <div class="col col-md-3"><label for="email-input" class=" form-control-label">Last Name</label></div>
                                            <div class="col-12 col-md-9"><input class=" form-control" id="username" name="lastname" type="text" value="<?php  echo $row['LastName'];?>"  required='true'></div>
                                          </div>
                                           <div class="details" style="display: inline-block;">
                                            <div class="col col-md-3"><label for="password-input" class=" form-control-label">Contact Number</label></div>
                                            <div class="col-12 col-md-9"> <input class="form-control " id="contactnumber" name="phone" type="text" value="<?php  echo $row['MobileNumber'];?>" required="true"></div>
                                          </div>
                                         <div class="details" style="display: inline-block;">
                                            <div class="col col-md-3"><label for="disabled-input" class=" form-control-label">Email</label></div>
                                            <div class="col-12 col-md-9"><input class="form-control " id="email" name="email" type="email" value="<?php  echo $row['Email'];?>" required="true" ></div>
                                        </div>
                                        <div class="details" style="width:auto;">
                                            <div class="col-12 col-md-9"><button type="submit" class="btn btn-primary btn-sm" name="update" >Update</button></div>
                                        </div>
                                        <?php } ?>
                                        
        </form>
       </div>
</body>
</html>