<?php
session_start();
error_reporting(0);
include('../Admin/includes/dbconnection.php');
$userid=$_SESSION['vpmsaid'];
$amount=500;
$query=mysqli_query($con, "insert into tblwallet(UserId, Amount) value('$userid', '$amount' )");
if ($query) {
echo '<script>alert("Transaction was succesful)</script>';
echo "<script>window.location.href='dashboard.php'</script>";
}

?>