<?php
session_start();
error_reporting(0);
include('../Admin/includes/dbconnection.php');

if(isset($_POST['Register']))
  {
    $fname=$_POST['firstname'];
    $lname=$_POST['lastname'];
    $contno=$_POST['phone'];
    $email=$_POST['email'];
    $password=md5($_POST['password']);

    $ret=mysqli_query($con, "select Email from users where Email='$email' || MobileNumber='$contno'");
    $result=mysqli_fetch_array($ret);
    if($result>0){

echo '<script>alert("This email or Contact Number already associated with another account")</script>';
    }
    else{
    $query=mysqli_query($con, "insert into users(FirstName, LastName, MobileNumber, Email, Password) value('$fname', '$lname','$contno', '$email', '$password' )");
    if ($query) {
        header('location:login.php');
    echo "You have successfully registered";
  }
  else
    {
      echo '<script>alert("Something Went Wrong. Please try again")</script>';
    }
}
}
  ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
</head>
<body class="body">
   <div class="regform" style="margin-top: 50px;margin-left: 30%;background-color: aliceblue;width:450px">
   <div style="background-color:green;">
      <div align="center" style="border-radius: 50%;background-color: white;width: 120px;margin-left: 35%;padding: 5px;">
            <h1>Create  Account
        </div> 
   </div>  
   <form action="" class="form" method="post" >   
        <div  style="margin-left: 5%;font-size:24px;margin-top: 5px;">
            <label for="">First Name</label>
            <input style="width:200px;height:25px;padding-left:10px;font-size:20px;" type="text" placeholder="First Name" id="firstname" onkeyup="first()" name="firstname" required>
        </div>
        <div class="details" style="margin-left: 5%;font-size:24px;margin-top: 5px;">
            <label for="">Last Name</label>
            <input style="width:200px;padding-left:10px;font-size:20px;height:25px;" type="text" placeholder="Last Name" id="lastname" name="lastname" onkeyup="last()" required >
        </div>
        <div class="details" style="margin-left: 5%;font-size:24px;margin-top: 5px;">
            <label for="">Email</label>
            <input style="width:200px;padding-left:10px;font-size:20px;height:25px;" type="email" placeholder="Email" name="email"  required>
        </div>
        <div class="details" style="margin-left: 5%;font-size:24px;margin-top: 5px;">
            <label for="">Mobile No </label>
            <input style="width:200px;padding-left:10px;font-size:20px;height:25px;" type="number" placeholder="Mobile Number " name="phone"  required>
        </div>
        <div class="details" style="margin-left: 5%;font-size:24px;margin-top: 5px;">
            <label for="">Password</label>
            <input style="width:200px;padding-left:10px;font-size:20px;height:25px;" type="password" placeholder="Password" name="password" id="password"  onkeyup="passcheck()" required>
        </div>
        <div class="details" style="margin-left: 5%;font-size:24px;margin-top: 5px;">
            <label for="">Confirm Password</label>
            <input style="width:200px;padding-left:10px;font-size:20px;height:25px;" type="password" placeholder="Repeat Password" id="cpassword" onkeyup="passcheck()" required>
        </div>
        <div class="details"style="margin-left: 5%;font-size:24px;margin-top: 5px;" >
            <button style="width:300px;font-size:26px;height:30px;border-radius: 50px;margin-left: 15%;background-color:blue;" type="submit" name="Register">Register</button>
        </div>
        <div class="error" id="errors" style="display: none;">
            <h20 style="color:yellow ;margin-left: 50px;">Password requirements</h20>
                <ul id="errors" >
                    <li id="upper">Atleast one uppercase</li>
                    <li id="lower">Atleast one lowercase</li>
                    <li id="special">Atleast one special symbol</li>
                    <li id="number">Atleast one number</li>
                    <li id="length">Atleast 6 characters</li>
                </ul>
            </div>
    </form>
   </div>
   <script type="text/javascript">
    function passcheck(){
    var password=document.getElementById("password");
    var cpassword=document.getElementById("cpassword");
    var upper=document.getElementById("upper");
    var lower=document.getElementById("lower");
    var special=document.getElementById("special");
    var number=document.getElementById("number");
    var length=document.getElementById("length");
    var errors=document.getElementById("errors");
    var match=document.getElementById("match");
  
    
    //uppercase
    if(password.value.match(/[A-Z]/)){
        upper.style.color="green";
    }
    else{
        upper.style.color="red";
        password.style.borderBlockColor="red"
    }
    //lowercase
    if(password.value.match(/[a-z]/)){
        lower.style.color="green";
    }
    else{
        lower.style.color="red";
        password.style.borderBlockColor="red"
    }
    //special characters
    if(password.value.match(/[@,#,$,%,^,&,*,+]/)){
        special.style.color="green";
    }
    else{
        special.style.color="red";
        password.style.borderBlockColor="red"
    }
    //a number
    if(password.value.match(/[0-9]/)){
        number.style.color="green";
    }
    else{
        number.style.color="red";
        password.style.borderBlockColor="red"
    }
//Atleast 6 characters
    if(password.value.length >6 ){
        length.style.color="green";
    }
    else{
        length.style.color="red";
        password.style.borderBlockColor="red"
    }
    if(password.value == cpassword.value){
        errors.style.display="none";
        password.style.borderBlockColor="green"
        cpassword.style.borderBlockColor="green"

     }
     else{
        errors.style.display="block";
     }
}
function first(){
    var firstname=document.getElementById("firstname");
    //validating first name
    if(firstname.value.match(/[@,#,$,%,^,&,*,+,=,;]/)){
        firstname.style.borderBlockColor="red";
    }
    else{
        firstname.style.borderBlockColor="green";
        
    }
}
function last(){
//validating last name
    var lastname=document.getElementById("lastname");
    if(lastname.value.match(/[@,#,$,%,^,&,*,+,=,;]/)){
        lastname.style.borderBlockColor="red";
    }
    else{
        lastname.style.borderBlockColor="green";
    }    
}

   </script>
    
</body>
</html>