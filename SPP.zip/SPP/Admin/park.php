<?php
session_start();
error_reporting(0);
include('../Admin/includes/dbconnection.php');

if(isset($_POST['park'])){
 $ucode=random_int(0,100000);
$parkingnumber=$_POST['parkingno'];
$vehcol=$_POST['vehcol'];
$vehreno=$_POST['vehreno'];
$ownername=$_POST['ownername'];
$ownercontno=$_POST['ownercontno'];
$status=  'IN';
$remark='Vehicle is in';
$query=mysqli_query($con, "insert into  tblvehicle(Code,ParkingNumber,VehicleColor,RegistrationNumber,OwnerName,OwnerContactNumber,Remark,Status) value('$ucode','$parkingnumber','$vehcol','$vehreno','$ownername','$ownercontno','$remark','$status')");
if ($query) {
echo "<script>alert('Vehicle has been Parked Successfuly');</script>";
echo "<script>window.location.href='unpark.php'</script>";
$_SESSION['vehid']=$ucode;

}
else
{
 echo "<script>alert('Something Went Wrong. Please try again.');</script>";       
}
}
  ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../Admin/Assets/style.css">
    <title>Park Vehicle</title>
</head>
<body>
<body class="body">

   <div class="regform" style="margin-top: 50px;margin-left: 30%;background-color: aliceblue;width:500px">
    <form action="" class="form" method="post" >
        <h1 style="margin-left: 30px;">Park Vehicle </h1>
        <?php
$adminid=$_SESSION['vpmsaid'];
$ret=mysqli_query($con,"select * from users where ID='$adminid'");
$cnt=1;
while ($row=mysqli_fetch_array($ret)){

    ?>
                                           
                                           <div class="details" style="display: inline-block;">
                                            <div class="col col-md-3"><label for="text-input" class=" form-control-label" style="display: inline-block;">Parking Number</label></div>
                                            <div class="col-12 col-md-9"><input class=" form-control" id="parkingno" name="parkingno" type="text"  required="true"></div>
                                          </div>
                                           <div class="details" style="display: inline-block;">
                                            <div class="col col-md-3"><label for="text-input" class=" form-control-label" style="display: inline-block;">Vehicle Color</label></div>
                                            <div class="col-12 col-md-9"><input class=" form-control" id="vehcol" name="vehcol" type="text" required="true" ></div>
                                          </div>
                                          <div class="details" style="display: inline-block;">
                                            <div class="col col-md-3"><label for="email-input" class=" form-control-label">Registration Number</label></div>
                                            <div class="col-12 col-md-9"><input class=" form-control" id="vehreno" name="vehreno" type="text" value="<?php  echo $row['RegistrationNumber'];?>"  required='true'></div>
                                          </div>
                                           <div class="details"  style="display: inline-block;">
                                            <div class="col col-md-3"><label for="password-input" class=" form-control-label">Owner Name</label></div>
                                            <div class="col-12 col-md-9"> <input class="form-control " id="ownername" name="ownername" type="text" value="<?php  echo $row['FirstName'] ; echo $row['LastName']; ?>" required="true"></div>
                                          </div>
                                         <div class="details">
                                            <div class="col col-md-3"><label for="disabled-input" class=" form-control-label">Owner Contact Number</label></div>
                                            <div class="col-12 col-md-9"><input class="form-control " id="ownercontno" name="ownercontno" type="ownercontno" value="<?php  echo $row['MobileNumber'];?>" required="true" ></div>
                                        </div>
                                        <div class="details" style="width:auto;">
                                            <div class="col-12 col-md-9"><button type="submit" class="btn btn-primary btn-sm" name="park" >Park</button></div>
                                        </div>
                                        <?php } ?>
        
    </form>
   </div>
   <?php include('dashboard.php') ?>
</body>
</html>