<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['admin']==0)) {
  header('location:logout.php');
  }

  ?>

<!DOCTYPE html>
<html lang="en">
<head>

    <link rel="stylesheet" href="Assets/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
    <title>Admin Dashboard</title>
</head>
<body class="body">
    <style>
        
@media (max-width: 626px) {
    .adminheader{
        display:list;
        font-size:10px;
    }
}


    </style>
    
   
    <div class="adminheader"style="height:36px"  >  
        <ul >
            <li style="margin-top:3px; height:40px"><p style="font-size:22px;">Smart parking & traffic solution <img src="../Admin/images/admin.jpeg"style="margin-top:0px;"  alt=""></p></li>
            <li style="margin-top:5px;" ><a  href="traffic.php">Navigate</a></li>
            <li><a href="bwdateusers.php"> Users</a></li>
            <li><a href="bwdates-report.php">ParkingReport</a></li>
            <li><a href="Registration.php">AddAdmin</a></li>
            <li><a href="profile.php">Profile</a></li>
            <li><a href="logout.php"><img src="../Admin/images/logout.png" alt="" style="margin-left: 0px;margin-top: -10px;width: 50px; height: 26px; border-radius: 5px;"></a></li>
        </ul>
    </div>
   
    <div class="adminside" style="margin-left: 2px;margin-top: -25px;">
        <ul>
            <li style="margin-top:30px;list-style:none;"><a style="text-decoration:none;color:black;" href="addslots.php"><img src="../Admin/images/parking.png" alt="" style="margin-top: 5px;"> Add Slots</a></li>
            <li style="margin-top:30px;list-style:none;"><a style="text-decoration:none;color:black;" href="fslots.php">Free Slots</a></li>
            <li style="margin-top:30px;list-style:none;"><a style="text-decoration:none;color:black;" href="oslots.php">Occupied Slots</a></li><hr style="margin-left: -40px;">
            <li><a href="bwdateincome.php">
                <img src="../Admin/images/wallet.png" alt="">
                <?php
                   include('includes/dbconnection.php');
                  $result =mysqli_query($con,"SELECT SUM(ParkingCharge) AS total FROM tblvehicle");
                   if ($result ) {
                 // Fetch the sum value
                  $row = mysqli_fetch_assoc($result );
                  $totalSum = $row['total'];
    
                  // Display or use the total sum as needed
                  echo "Total Income: $totalSum";
                   }
                ?>
              </a>
            </li>
        </ul>
    </div>
   
</body>
</html>