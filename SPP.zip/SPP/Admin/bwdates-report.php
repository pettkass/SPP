<?php
session_start();
error_reporting(0);
include('../includes/dbconnection.php');
error_reporting(0);
if (strlen($_SESSION['admin']==0)) {
  header('location:logout.php');
  } else{
    if(isset($_POST['submit']))
  {
    $fdate=$_POST['fromdate'];
    $tdate=$_POST['todate'];
    $_SESSION['fdate']=$fdate;
    $_SESSION['tdate']=$tdate;
    echo "<script>window.location.href='reportsdetails.php'</script>";
  }
  ?>
<!doctype html>
<html class="no-js" lang="">
<head>
    
    <title>Reports</title>
    <link rel="apple-touch-icon" href="https://i.imgur.com/QRAUqs9.png">
    <link rel="shortcut icon" href="https://i.imgur.com/QRAUqs9.png">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/normalize.css@8.0.0/normalize.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/lykmapipo/themify-icons@0.1.2/css/themify-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/pixeden-stroke-7-icon@1.2.3/pe-icon-7-stroke/dist/pe-icon-7-stroke.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.2.0/css/flag-icon.min.css">
    <link rel="stylesheet" href="assets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>

</head>
<body>
   <?php include_once('dashboard.php');?>
   <div style="margin-left: 30%;margin-top: -40%;width:550px" class="card-body card-block">
                                <form style="display:inline-block;font-size:20px;background-color: aliceblue;width:500px"  method="post" enctype="multipart/form-data" class="form-horizontal" name="bwdatesreport">
                                <h1 style="margin-left: 10%;font-size:30px;">Between Dates Parking Reports</h1>
                                    <p style="font-size:16px; color:red" align="center"> <?php if($msg){
    echo $msg;
  }  ?> </p>
                                    <div style="font-size:25px;margin-left: 5%;" class="row form-group">
                                        <div class="col col-md-3"><label  for="text-input" class=" form-control-label">From Date</label></div>
                                        <div  class="col-12 col-md-9"><input style="display: inline-flexbox;margin-left: 20px;margin: -3px;padding: 5px 5px;border-top: -1px;width: 300px;" type="date" name="fromdate" id="fromdate" class="form-control" required="true"></div>
                                    </div>
                                    <div style="font-size:25px;margin-left: 5%;"  class="row form-group">
                                        <div class="col col-md-3"><label for="email-input" class=" form-control-label">To Date</label></div>
                                        <div class="col-12 col-md-9"><input style="display: inline-flexbox;margin-left: 30px;margin: -3px;padding: 5px 5px;border-top: -1px;width: 300px;"type="date" name="todate"  class="form-control" required="true"></div>
                                    </div>                                   
                                    
        <button type="submit" style="padding-bottom:10px;margin-left: 50px;margin-top: 5px;
    width: 80%;
    margin-left: 30px;
    padding: 5px 5px;
    border-radius: 50px;background-color: blue;" class="btn btn-primary btn-sm" name="submit" >Submit</button></p>
                                </form>
                            </div>
</body>
</html>
<?php }  ?>