<?php include_once('dashboard.php');?>
 <?php
session_start();
error_reporting(0);
include('../Admin/includes/dbconnection.php');
if (strlen($_SESSION['admin']==0)) {
  header('location:logout.php');
  } else{
$vehreno=$_SESSION['vehid'];
$ret=mysqli_query($con,"select * from tblvehicle where Code='$vehreno'");
$cnt=1;
while ($row=mysqli_fetch_array($ret)) {
  ?>

<div  id="exampl" style="margin-top: -680px;margin-left: 30%;background-color: aliceblue;width:500px">

      <table border="1" style="background-color: aliceblue;"  class="table table-bordered mg-b-0">
        <tr>
          <th colspan="4" style="text-align: center; font-size:22px;"> Vehicle Parking Receipt</th>
        </tr>
   
   <tr><th>Receipt Number</th>
                                   <td><?php  echo $row['Code'];?></td>
                                   </tr>
                                   
                                   <tr>
                                <th>Parking Number</th>
                                   <td><?php  echo $row['ParkingNumber'];?></td>
                                   </tr>
                                   
                                   <tr>
                                <th>Vehicle Color</th>
                                   <td><?php  echo $packprice= $row['VehicleColor'];?></td>
                             
                                <th>Registration Number</th>
                                   <td><?php  echo $row['RegistrationNumber'];?></td>
                                   </tr>
                                   <tr>
                                    <th>Owner Name</th>
                                      <td><?php  echo $row['OwnerName'];?></td>
                                  
                                       <th>Owner Contact Number</th>
                                        <td><?php  echo $row['OwnerContactNumber'];?></td>
                                    </tr>
                                    <tr>
                               <th>In Time</th>
                                <td><?php  echo $row['InTime'];?></td>
    <th>Status</th>
    <td> <?php  
if($row['Status']=="IN")
{
  echo "Incoming Vehicle";
}
if($row['Status']=="OUT")
{
  echo "Outgoing Vehicle";
}

     ;?></td>
  </tr>
<?php if($row['Remark']!=""){ ?>
<tr>
<th>Out time</th>
<td><?php  echo $row['OutTime'];?></td>
<th>Rarking Charge</th>
<td><?php  echo $row['ParkingCharge'];?></td>
</tr>
<tr>
  <th>Remark</th>
  <td colspan="3"><?php  echo $row['Remark'];?></td>

</tr>


<?php } ?>
  <tr>
    <td colspan="4" style="text-align:center; cursor:pointer"><i class="fa fa-print fa-2x" aria-hidden="true" OnClick="CallPrint(this.value)"  >PRINT</i></td>
  </tr>

</table>
            <?php }}  ?>
          </div></div>
            <script>
function CallPrint(strid) {
var prtContent = document.getElementById("exampl");
var WinPrint = window.open('', '', 'left=0,top=0,width=800,height=900,toolbar=0,scrollbars=0,status=0');
WinPrint.document.write(prtContent.innerHTML);
WinPrint.document.close();
WinPrint.print();
WinPrint.close();
}
</script> 
