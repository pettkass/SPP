<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['admin']==0)) {
  header('location:logout.php');
  }

  ?>
<!doctype html>

<html class="no-js" lang="">
<head>
   
    <title>Users</title>
    <link rel="apple-touch-icon" href="https://i.imgur.com/QRAUqs9.png">
    <link rel="shortcut icon" href="https://i.imgur.com/QRAUqs9.png">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/normalize.css@8.0.0/normalize.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/lykmapipo/themify-icons@0.1.2/css/themify-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/pixeden-stroke-7-icon@1.2.3/pe-icon-7-stroke/dist/pe-icon-7-stroke.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.2.0/css/flag-icon.min.css">
    <link rel="stylesheet" href="assets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="Assets/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>

</head>
<body>
<?php include_once('dashboard.php');?>
        <div class="content" style="background-color: aliceblue;margin-left: 20%;margin-top: -42%;width:800px" class="card-body card-block">
            <div class="animated fadeIn">
                <div class="row">

                <div class="col-lg-12" style="diplay:inline-block;">
                    <div class="card" >
                        <div class="card-body" id="example">
                            <?php

                                $fdate=$_SESSION['fdate'];
                                $tdate= $_SESSION['tdate'];     
                            ?>
<h5 align="center" style="color:blue;font-size:20px;padding-left: 10px;padding-top: 10px;">Users Report from <?php echo $fdate?> to <?php echo $tdate?></h5>
                             <table border="1" style="color:black;font-size:20px;margin-left:10%;margin-top: -10px;" class="table">
                <thead style="color:black;font-size:20px;padding-top: 3%;padding-left: 10px;">
                                        <tr>
                                            <tr>
                  <th >S.NO</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Mobile Number</th>
                    <th>Email</th>
                   
                                        </tr>
                                        </tr>
                                        </thead>
               <?php
$ret=mysqli_query($con,"select *from   users where date(AdminRegdate) between '$fdate' and '$tdate' ");
$cnt=1;
while ($row=mysqli_fetch_array($ret)) {

?>
              
                <tr>
                  <td><?php echo $cnt;?></td>
                  <td><?php  echo $row['FirstName'];?></td>
                  <td><?php  echo $row['LastName'];?></td>
                  <td><?php  echo $row['MobileNumber'];?></td>
                  <td><?php  echo $row['Email'];?></td>
                  
                </tr>
                <?php 
$cnt=$cnt+1;
}?>
              </table>

                    </div>
 <button align="center" style="margin-left:30%;margin-top:5px; width:300px;background-color:blue; border-radius: 50px" onclick="CallPrint()">Print</button>
                </div>
               
            </div>
        </div>
       
        
    </div>
<script >
function CallPrint(strid) {
var prtContent = document.getElementById("example");
var WinPrint = window.open('', '', 'left=0,top=0,width=800,height=900,toolbar=0,scrollbars=0,status=0');
WinPrint.document.write(prtContent.innerHTML);
WinPrint.document.close();
WinPrint.print();
WinPrint.close();
}
</script> 


</body>
</html>
<?php   ?>