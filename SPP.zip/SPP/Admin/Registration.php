 <?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');

if(isset($_POST['register']))
  {
    $fname=$_POST['firstname'];
    $lname=$_POST['lastname'];
    $contno=$_POST['phone'];
    $email=$_POST['email'];
    $password=md5($_POST['password']);

    $ret=mysqli_query($con, "select Email from tbladmin where Email='$email' || MobileNumber='$contno'");
    $result=mysqli_fetch_array($ret);
    if($result>0){

echo '<script>alert("This email or Contact Number already associated with another account")</script>';
    }
    else{
    $query=mysqli_query($con, "insert into tbladmin(FirstName, LastName, MobileNumber, Email, Password) value('$fname', '$lname','$contno', '$email', '$password' )");
    if ($query) {
        header('location:dashboard.php');
    echo "You have successfully registered";
  }
  else
    {
      echo '<script>alert("Something Went Wrong. Please try again")</script>';
    }
}
}
  ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../Admin/Assets/style.css">
</head>

<body class="body">
   <div class="regform" style="margin-top: 50px;margin-left: 30%;">
    <form  method="post" class="form" >
        <h1 style="margin-left: 30px;">Register Admin</h1>
        <div class="details">
            <label for="">First Name</label>
            <input style="width:300px" type="text" placeholder="First Name" id="firstname" onkeyup="first()" required="True" name="firstname" >
        </div>
        <div class="details">
            <label for="">Last Name</label>
            <input style="width:300px" type="text" placeholder="Last Name" id="lastname" onkeyup="last()" name="lastname" required >
        </div>
        <div class="details">
            <label for="">Mobile Number </label>
            <input style="width:260px" type="number" placeholder="Mobile Number " name="phone"  required>
        </div>
        <div class="details">
            <label for="">Email Address</label>
            <input style="width:270px" type="email" placeholder="Email" name="email"  required>
        </div>
        <div class="details">
            <label for="">Password</label>
            <input style="width:310px" type="password" placeholder="Password" id="password"  name="password" onkeyup="passcheck()" required>
        </div>
        <div class="details">
            <label for="">Confirm Password</label>
            <input style="width:240px" type="password" placeholder="Repeat Password" id="cpassword" name="cpassword" onkeyup="passcheck()" required>
        </div>
        <div class="details" >
            <button type="submit" name="register">Register</button>
        </div>
        <div class="error" id="errors"style="display: none;" >
            <h20 style="color:yellow ;margin-left: 50px;">Password requirements</h20>
                <ul id="errors">
                    <li id="upper">Atleast one uppercase</li>
                    <li id="lower">Atleast one lowercase</li>
                    <li id="special">Atleast one special symbol</li>
                    <li id="number">Atleast one number</li>
                    <li id="length">Atleast 6 characters</li>
                </ul>
            </div>
    </form>
   </div>
   <script type="text/javascript">
    function passcheck(){
    var password=document.getElementById("password");
    var cpassword=document.getElementById("cpassword");
    var upper=document.getElementById("upper");
    var lower=document.getElementById("lower");
    var special=document.getElementById("special");
    var number=document.getElementById("number");
    var length=document.getElementById("length");
    var errors=document.getElementById("errors");
  
    
    //uppercase
    if(password.value.match(/[A-Z]/)){
        upper.style.color="green";
    }
    else{
        upper.style.color="red";
        password.style.borderBlockColor="red"
    }
    //lowercase
    if(password.value.match(/[a-z]/)){
        lower.style.color="green";
    }
    else{
        lower.style.color="red";
        password.style.borderBlockColor="red"
    }
    //special characters
    if(password.value.match(/[@,#,$,%,^,&,*,+]/)){
        special.style.color="green";
    }
    else{
        special.style.color="red";
        password.style.borderBlockColor="red"
    }
    //a number
    if(password.value.match(/[0-9]/)){
        number.style.color="green";
    }
    else{
        number.style.color="red";
        password.style.borderBlockColor="red"
    }
//Atleast 6 characters
    if(password.value.length >6 ){
        length.style.color="green";
    }
    else{
        length.style.color="red";
        password.style.borderBlockColor="red"
    }
    if(password.value == cpassword.value){
        errors.style.display="none";
        password.style.borderBlockColor="green"
        cpassword.style.borderBlockColor="green"

     }
     else{
        errors.style.display="block";
     }
}
function first(){
    var firstname=document.getElementById("firstname");
    //validating first name
    if(firstname.value.match(/[@,#,$,%,^,&,*,+,=,;]/)){
        firstname.style.borderBlockColor="red";
    }
    else{
        firstname.style.borderBlockColor="green";
        
    }
}
function last(){
//validating last name
    var lastname=document.getElementById("lastname");
    if(lastname.value.match(/[@,#,$,%,^,&,*,+,=,;]/)){
        lastname.style.borderBlockColor="red";
    }
    else{
        lastname.style.borderBlockColor="green";
    }    
}

   </script>
    
</body>
<?php include_once('dashboard.php');?>;
</html>