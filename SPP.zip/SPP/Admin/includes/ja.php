<?php
$p=100;
$e=md5(var);
echo ($e);
?>