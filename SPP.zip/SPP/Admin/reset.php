<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
error_reporting(0);

if(isset($_POST['passupdate']))
  {
    $contactno=$_SESSION['phone'];
    $email=$_SESSION['email'];
    $password=md5($_POST['password']);

        $query=mysqli_query($con,"update tbladmin set Password='$password'  where  Email='$email' && MobileNumber='$contactno' ");
   if($query)
   {
echo "<script>alert('Password successfully changed');</script>";
session_destroy();
   }
  
  }
  ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../Admin/Assets/style.css">
</head>
<body class="body">
   <div class="regform" style="margin-top: 50px;margin-left: 30%;">
    <form  method="post" class="form" >
        <h1 style="margin-left: 30px;">Create New Password</h1>
        <div class="details">
            <label for="">New Password</label>
            <input type="password" placeholder="New Password" id="password" name="password" onkeyup="passcheck()" required>
        </div>
        <div class="details">
            <label for="">Confirm Password</label>
            <input type="password" placeholder="Repeat Password" id="cpassword" name="cpassword" onkeyup="passcheck()" required>
        </div>
        <div class="details" >
            <button type="submit" name="passupdate">Update</button>
        </div>
        <div class="error" id="errors"style="display: none;" >
            <h20 style="color:yellow ;margin-left: 50px;">Password requirements</h20>
                <ul id="errors">
                    <li id="upper">Atleast one uppercase</li>
                    <li id="lower">Atleast one lowercase</li>
                    <li id="special">Atleast one special symbol</li>
                    <li id="number">Atleast one number</li>
                    <li id="length">Atleast 6 characters</li>
                </ul>
            </div>
    </form>
   </div>
   <script type="text/javascript">
    function passcheck(){
    var password=document.getElementById("password");
    var cpassword=document.getElementById("cpassword");
    var upper=document.getElementById("upper");
    var lower=document.getElementById("lower");
    var special=document.getElementById("special");
    var number=document.getElementById("number");
    var length=document.getElementById("length");
    var errors=document.getElementById("errors");
  
    
    //uppercase
    if(password.value.match(/[A-Z]/)){
        upper.style.color="green";
    }
    else{
        upper.style.color="red";
        password.style.borderBlockColor="red"
    }
    //lowercase
    if(password.value.match(/[a-z]/)){
        lower.style.color="green";
    }
    else{
        lower.style.color="red";
        password.style.borderBlockColor="red"
    }
    //special characters
    if(password.value.match(/[@,#,$,%,^,&,*,+]/)){
        special.style.color="green";
    }
    else{
        special.style.color="red";
        password.style.borderBlockColor="red"
    }
    //a number
    if(password.value.match(/[0-9]/)){
        number.style.color="green";
    }
    else{
        number.style.color="red";
        password.style.borderBlockColor="red"
    }
//Atleast 6 characters
    if(password.value.length >6 ){
        length.style.color="green";
    }
    else{
        length.style.color="red";
        password.style.borderBlockColor="red"
    }
    if(password.value == cpassword.value){
        errors.style.display="none";
        password.style.borderBlockColor="green"
        cpassword.style.borderBlockColor="green"

     }
     else{
        errors.style.display="block";
     }
}
   </script>
    
</body>
</html>