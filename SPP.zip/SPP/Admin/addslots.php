<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');

if(isset($_POST['add']))
  {
    $label=$_POST['label'];
    $Status=$_POST['Status'];
    $ret=mysqli_query($con, "select Label from tblslots where Label='$$label'");
    $result=mysqli_fetch_array($ret);
    if($result){

    echo '<script>alert("The slot is  already Registered")</script>';
    }else{
    $query=mysqli_query($con, "insert into tblslots(Label, Status) value('$label', '$Status')");
    if ($query) {
        echo '<script>alert("slot successfully Added")</script>';
        header('location:dashboard.php');
  }
  else
    {
      echo '<script>alert("Something Went Wrong. Please try again")</script>';
    }
}
}
  ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../Admin/Assets/style.css">
</head>

<body class="body">
   <div class="regform" style="margin-top: 50px;margin-left: 30%;">
    <form  method="post" class="form" >
        <h1 style="margin-left: 30%;">Add slots</h1>
        <div class="details">
            <label for="">Slot label</label>
            <input style="width:300px" type="text" placeholder="Slot label" id="label" required="True" name="label" >
        </div>
        <div class="details">
            <label for="">Status</label>
            <input style="width:300px" type="text" placeholder="Status" id="Status" name="Status" required >
        </div>
       
        <div class="details" >
            <button type="submit" name="add">Add</button>
        </div>
        
    </form>
   </div>

    
</body>
<?php include_once('dashboard.php');?>
</html>