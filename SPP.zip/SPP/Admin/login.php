<?php
session_start();
error_reporting(0); 
include('includes/dbconnection.php');

if(isset($_POST['login']))
  {
    $email=$_POST['email'];
    $password=md5($_POST['password']);
    $query=mysqli_query($con,"select *from tbladmin where  Email='$email' && Password='$password' ");
    $ret=mysqli_fetch_array($query);
    if($ret>0){
        $_SESSION['admin']=$ret['ID'];
     header('location:dashboard.php');
    }
    else{
  
     echo "<script>alert('Invalid Details.');</script>";
    }
  }
  ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link rel="stylesheet" href="../admin/Assets/style.css">
</head>
<body>
    <div class="regform" style="margin-top: 50px;margin-left: 30%;background-color: aliceblue;width:500px">
    <div style="background-color:green;">
      <div align="center" style="border-radius: 50%;background-color: white;width: 120px;margin-left: 40%;padding: 5px;">
            <h1>Admin Login</h1>
        </div> 
   </div> 
        <form   method="post" class="form"  style="margin-top: 20px;">
            <div class="details" style="margin-left: 5%;font-size:26px;margin-top: 5px;">
                <label for="">Email</label>
                <input  style="width:300px;padding-left:30px;font-size:20px;height:30px;border-radius: 50px;" type="email" placeholder="Email" name="email"  required>
            </div>
            <div class="details" style="margin-left: 5%;font-size:30px;margin-top: 5px;">
                <label for="">Password</label>
                <input  style="width:280px;padding-left:30px;font-size:20px;height:30px;border-radius: 50px;" type="password" placeholder="Password" id="password" name="password"   required>
            </div>
            <div class="alternative">
                <li style="display: inline-block;margin-left: 35px;font-size: 28px; font-weight: bold;border-radius: 5px;"><a href="forgotpassword.php" style="color: red;margin-top:5px">Forgot Pasword?</a></li>
            <div class="details" >
                <button style="width:300px;font-size:26px;height:40px;border-radius: 50px;margin-left: 15%;background-color:blue;" type="submit" name="login">Log in</button>
            </div>
        </form>
       </div>
</body>
</html>