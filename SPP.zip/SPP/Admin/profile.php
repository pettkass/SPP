<?php
session_start();
error_reporting(0);
include('../Admin/includes/dbconnection.php');
    if(isset($_POST['update'])){
    $adminid=$_SESSION['admin'];
    $fname=$_POST['firstname'];
    $lname=$_POST['lastname'];
    $phone=$_POST['phone'];
    $email=$_POST['email'];  
    
    $query=mysqli_query($con, "update tbladmin set FirstName='$fname', LastName='$lname', MobileNumber='$phone', Email='$email' where ID='$adminid'");
    if ($query) {
    echo '<script>alert("Admin profile has been updated.")</script>';
  }
  else
    {
      echo '<script>alert("Something Went Wrong. Please try again")</script>';
    }
  }
  ?>
<!doctype html>
<html class="no-js" lang="">
<head>
    <title>Admin Profile</title>
    <link rel="apple-touch-icon" href="https://i.imgur.com/QRAUqs9.png">
    <link rel="shortcut icon" href="https://i.imgur.com/QRAUqs9.png">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/normalize.css@8.0.0/normalize.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/lykmapipo/themify-icons@0.1.2/css/themify-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/pixeden-stroke-7-icon@1.2.3/pe-icon-7-stroke/dist/pe-icon-7-stroke.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.2.0/css/flag-icon.min.css">
    <link rel="stylesheet" href="assets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="Assets/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="../admin/Assets/style.css">
</head>
<body>
  <?php include('dashboard.php') ?>
    <div style="margin-left: 30%;margin-top: -40%;width:500px;background-color: aliceblue">
        <form  method="post"  style="display:inline-block;font-size:20px;">
            <h1 style="margin-left: 30px;">Admin Profile Details</h1>
            <?php
          $adminid=$_SESSION['admin'];
                $ret=mysqli_query($con,"select * from tbladmin where ID='$adminid'");
                $cnt=1;
                while ($row=mysqli_fetch_array($ret)){

                    ?>
                                           <div class="details" style="display: inline-block;">
                                            <div class="col col-md-3"><label for="text-input" class=" form-control-label" style="display: inline-block;">First Name</label></div>
                                            <div class="col-12 col-md-9"><input style="width: 200px;" class=" form-control" id="adminname" name="firstname" type="text" value="<?php  echo $row['FirstName'];?>"></div>
                                          </div>
                                          <div class="details" style="display: inline-block;">
                                            <div class="col col-md-3"><label for="email-input" class=" form-control-label">Last Name</label></div>
                                            <div class="col-12 col-md-9"><input style="width: 200px;" class=" form-control" id="username" name="lastname" type="text" value="<?php  echo $row['LastName'];?>"  required='true'></div>
                                          </div>
                                           <div class="details" style="display: inline-block;">
                                            <div class="col col-md-3"><label for="password-input" class=" form-control-label">Contact Number</label></div>
                                            <div class="col-12 col-md-9"> <input style="width: 200px;" class="form-control " id="contactnumber" name="phone" type="text" value="<?php  echo $row['MobileNumber'];?>" required="true"></div>
                                          </div>
                                         <div class="details" style="display: inline-block;">
                                            <div class="col col-md-3"><label for="disabled-input" class=" form-control-label">Email</label></div>
                                            <div class="col-12 col-md-9"><input style="width: 200px;" class="form-control " id="email" name="email" type="email" value="<?php  echo $row['Email'];?>" required="true" ></div>
                                        </div>
                                        <div class="details" style="width:auto;padding-bottom:10px;">
                                            <div class="col-12 col-md-9"><button type="submit"style="background-color:blue;" class="btn btn-primary btn-sm" name="update" >Update</button></div>
                                        </div>
                                        <?php } ?>
                                        
        </form>
       </div>
</body>
</html>