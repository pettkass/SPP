-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 04, 2024 at 02:48 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `parking`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbladmin`
--

CREATE TABLE `tbladmin` (
  `ID` int(100) NOT NULL,
  `FirstName` varchar(120) DEFAULT NULL,
  `LastName` varchar(120) DEFAULT NULL,
  `MobileNumber` bigint(10) DEFAULT NULL,
  `Email` varchar(200) DEFAULT NULL,
  `Password` varchar(120) DEFAULT NULL,
  `AdminRegdate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbladmin`
--

INSERT INTO `tbladmin` (`ID`, `FirstName`, `LastName`, `MobileNumber`, `Email`, `Password`, `AdminRegdate`) VALUES
(6, 'Admin', 'Admin', 123456789, 'admin@gmail.com', 'fe5db99a473f2e239b322e29ef3e7b3a', '2024-02-15 07:35:24');

-- --------------------------------------------------------

--
-- Table structure for table `tblslots`
--

CREATE TABLE `tblslots` (
  `ID` int(10) NOT NULL,
  `Label` varchar(120) DEFAULT NULL,
  `Date` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `Status` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblslots`
--

INSERT INTO `tblslots` (`ID`, `Label`, `Date`, `Status`) VALUES
(1, 'A', '2024-03-04 07:31:57', 'F'),
(2, 'B', '2024-03-02 12:19:08', 'F'),
(3, 'C', '2024-02-24 12:52:41', 'F'),
(4, 'D', '2024-02-24 13:17:08', 'F'),
(5, 'E', '2024-02-17 11:11:38', 'F'),
(7, 'A2', '2024-03-02 12:17:35', 'F'),
(8, 'A3', '2024-03-04 08:00:18', 'F'),
(9, 'A4', NULL, 'F'),
(10, 'A5', '2024-02-19 12:46:41', 'F'),
(11, 'A6', NULL, 'F'),
(12, 'A7', NULL, 'F'),
(13, 'A8', NULL, 'F'),
(14, 'A9', NULL, 'F'),
(15, 'A1o', NULL, 'F'),
(16, 'A1', NULL, 'F'),
(17, 'A3', '2024-03-04 08:00:18', 'F'),
(18, 'A30', NULL, 'F'),
(19, 'A30', NULL, 'F'),
(20, 'A60', NULL, 'F'),
(21, 'A30', NULL, 'F'),
(22, 'B1', NULL, 'F');

-- --------------------------------------------------------

--
-- Table structure for table `tblvehicle`
--

CREATE TABLE `tblvehicle` (
  `ID` int(10) NOT NULL,
  `Code` varchar(120) NOT NULL,
  `ParkingNumber` varchar(120) DEFAULT NULL,
  `VehicleColor` varchar(120) DEFAULT NULL,
  `RegistrationNumber` varchar(120) DEFAULT NULL,
  `OwnerName` varchar(120) DEFAULT NULL,
  `OwnerContactNumber` bigint(10) DEFAULT NULL,
  `InTime` timestamp NULL DEFAULT current_timestamp(),
  `OutTime` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `ParkingCharge` varchar(120) NOT NULL,
  `Remark` mediumtext NOT NULL,
  `Status` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblvehicle`
--

INSERT INTO `tblvehicle` (`ID`, `Code`, `ParkingNumber`, `VehicleColor`, `RegistrationNumber`, `OwnerName`, `OwnerContactNumber`, `InTime`, `OutTime`, `ParkingCharge`, `Remark`, `Status`) VALUES
(1, '81872', '24', 'white', 'kcy231f', 'josemwonge', 906882797, '2024-02-15 07:12:11', '2024-02-15 07:12:46', '200', 'Vehicle is out', 'OUT'),
(2, '81307', '36', 'yelloow', 'kaa001a', 'mwakajack', 863345671, '2024-02-15 07:16:13', NULL, '', 'Vehicle is in', 'IN'),
(3, '31872', '24', 'green', 'kaa002b', 'mwakajack', 863345671, '2024-02-15 07:17:24', '2024-02-15 07:17:51', '200', 'Vehicle is out', 'OUT'),
(4, '42966', '23', 'red', 'kjy789l', 'mwakajack', 863345671, '2024-02-16 08:42:08', '2024-02-16 08:44:21', '200', 'Vehicle is out', 'OUT'),
(5, '34936', '1', 'green', 'jun567n', 'junejack', 567890123, '2024-02-17 08:29:19', '2024-02-17 08:30:02', '200', 'Vehicle is out', 'OUT'),
(7, '20479', 'A', 'green', 'tyu456g', 'junekachilah', 567890123, '2024-02-17 10:47:14', '2024-02-17 10:53:06', '200', 'Vehicle is out', 'OUT'),
(8, '90942', 'B', 'red', 'ccc111c', 'junekachilah', 567890123, '2024-02-17 10:53:46', '2024-02-17 10:55:57', '200', 'Vehicle is out', 'OUT'),
(9, '32177', 'B', 'red', '456', 'junekachilah', 567890123, '2024-02-17 10:57:06', '2024-02-17 10:59:29', '200', 'Vehicle is out', 'OUT'),
(10, '39694', 'D', 'green', '6666', 'junekachilah', 567890123, '2024-02-17 11:00:36', '2024-02-17 11:00:58', '200', 'Vehicle is out', 'OUT'),
(11, '57533', 'A', 'green', '77', 'junekachilah', 567890123, '2024-02-17 11:01:28', '2024-02-17 11:07:34', '200', 'Vehicle is out', 'OUT'),
(12, '42161', 'A', 'red', 'ee', 'junekachilah', 567890123, '2024-02-17 11:08:04', '2024-02-17 11:08:19', '200', 'Vehicle is out', 'OUT'),
(13, '55367', 'A', 'green', 'ddd111d', 'junekachilah', 567890123, '2024-02-17 11:12:03', '2024-02-17 11:12:32', '200', 'Vehicle is out', 'OUT'),
(14, '42009', 'A', 'white', 'yyy', 'junekachilah', 567890123, '2024-02-17 11:16:31', '2024-02-17 11:16:59', '200', 'Vehicle is out', 'OUT'),
(15, '51959', 'C', 'green', 'hyyt', 'mwakajack', 863345671, '2024-02-17 11:20:46', '2024-02-17 11:21:01', '200', 'Vehicle is out', 'OUT'),
(17, '2262', 'D', 'white', 'ykkk', 'junekachilah', 567890123, '2024-02-17 11:23:52', '2024-02-17 11:24:12', '200', 'Vehicle is out', 'OUT'),
(18, '95313', 'A2', 'yelloow', 'kcy231f', 'junekachilah', 567890123, '2024-02-17 11:31:54', '2024-02-17 11:32:16', '200', 'Vehicle is out', 'OUT'),
(19, '29350', 'A', 'green', 'kby201j', 'mwakajack', 863345671, '2024-02-17 11:50:59', '2024-02-17 11:51:23', '200', 'Vehicle is out', 'OUT'),
(20, '60196', 'D', 'green', 'kby201j', 'mwakajack', 863345671, '2024-02-17 11:56:01', '2024-02-17 11:56:17', '200', 'Vehicle is out', 'OUT'),
(21, '89895', 'A', 'green', 'kby201j', 'junekachilah', 567890123, '2024-02-19 10:50:11', '2024-02-19 10:50:26', '200', 'Vehicle is out', 'OUT'),
(22, '78427', 'C', 'green', 'kcy231f', 'junekachilah', 567890123, '2024-02-19 12:09:50', '2024-02-19 12:10:30', '200', 'Vehicle is out', 'OUT'),
(23, '88568', 'C', 'green', 'kcy231f', 'junekachilah', 567890123, '2024-02-19 12:11:45', '2024-02-19 12:11:50', '200', 'Vehicle is out', 'OUT'),
(24, '87593', 'B', 'white', 'kcz201v', 'junekachilah', 567890123, '2024-02-19 12:27:37', '2024-02-19 12:29:04', '200', 'Vehicle is out', 'OUT'),
(25, '83189', 'A', 'green', 'kby201j', 'june3kachilah', 567890123, '2024-02-19 12:32:29', '2024-02-19 12:32:44', '200', 'Vehicle is out', 'OUT'),
(26, '9100', '0', 'green', 'kby201j', 'june3kachilah', 567890123, '2024-02-19 12:34:21', '2024-02-19 12:34:29', '200', 'Vehicle is out', 'OUT'),
(27, '20943', 'D', 'yelloow', 'kcy231f', 'june3kachilah', 567890123, '2024-02-19 12:35:31', '2024-02-19 12:35:55', '200', 'Vehicle is out', 'OUT'),
(28, '28888', 'B', 'yelloow', 'kcy231f', 'joy34joy134', 6060606056, '2024-02-19 12:38:10', '2024-02-19 12:38:15', '200', 'Vehicle is out', 'OUT'),
(29, '64393', 'A5', 'red', 'kcy231f', 'june3kachilah', 567890123, '2024-02-19 12:46:17', '2024-02-19 12:46:41', '200', 'Vehicle is out', 'OUT'),
(30, '94529', 'B', 'green', 'kcy231f', 'josemwonge', 906882797, '2024-02-19 13:34:44', NULL, '', 'Vehicle is in', 'IN'),
(31, '84048', 'A3', 'white', 'kcy231f', 'tinda89uuu', 777777, '2024-02-19 13:58:50', '2024-02-19 13:59:11', '200', 'Vehicle is out', 'OUT'),
(32, '82813', 'C', 'green', 'kby201j', 'june3kachilah', 567890123, '2024-02-21 12:03:34', '2024-02-21 12:05:08', '200', 'Vehicle is out', 'OUT'),
(33, '41097', 'A2', 'red', 'kcz201v', 'junekachilah', 567890123, '2024-02-22 13:24:32', '2024-02-22 13:25:57', '200', 'Vehicle is out', 'OUT'),
(34, '41150', 'A', 'green', 'kby201j', 'josemwonge', 906882797, '2024-02-23 08:14:31', '2024-02-23 08:15:49', '200', 'Vehicle is out', 'OUT'),
(35, '69600', 'A2', 'yello', 'kcy231f', 'junekachilah', 567890123, '2024-02-23 09:02:06', '2024-02-23 09:02:56', '200', 'Vehicle is out', 'OUT'),
(36, '67320', 'C', 'white', 'kxz123y', 'danielmutisya', 701570901, '2024-02-24 12:52:22', '2024-02-24 12:52:41', '200', 'Vehicle is out', 'OUT'),
(37, '2618', 'D', 'green', 'kby201j', 'junekachilah', 567890123, '2024-02-24 13:02:09', '2024-02-24 13:02:51', '200', 'Vehicle is out', 'OUT'),
(38, '25037', 'D', 'green', 'kby201j', 'junejackson', 567890123, '2024-02-24 13:11:58', '2024-02-24 13:17:08', '200', 'Vehicle is out', 'OUT'),
(39, '8012', '0', 'green', 'kby201j', 'danielmutisya', 701570901, '2024-03-02 11:35:20', '2024-03-02 11:36:28', '200', 'Vehicle is out', 'OUT'),
(40, '36419', 'A2', 'green', 'kby201j', 'Eylaotieno', 987654321, '2024-03-02 11:38:51', NULL, '', 'Vehicle is in', 'IN'),
(41, '37044', 'B', 'green', 'kby201j', 'Eylaotieno', 987654321, '2024-03-02 12:18:59', '2024-03-02 12:19:08', '200', 'Vehicle is out', 'OUT'),
(42, '29669', 'A', 'green', 'kby201j', 'Eylaotieno', 987654321, '2024-03-04 07:31:25', '2024-03-04 07:31:57', '200', 'Vehicle is out', 'OUT'),
(43, '71077', 'A3', 'green', '567gyg', 'danielmutisya', 701570901, '2024-03-04 07:57:01', '2024-03-04 08:00:18', '50', 'Vehicle is out', 'OUT');

-- --------------------------------------------------------

--
-- Table structure for table `tblwallet`
--

CREATE TABLE `tblwallet` (
  `WID` int(10) NOT NULL,
  `UserId` varchar(120) DEFAULT NULL,
  `Amount` varchar(120) NOT NULL,
  `Date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblwallet`
--

INSERT INTO `tblwallet` (`WID`, `UserId`, `Amount`, `Date`) VALUES
(1, '10', '800', '2024-02-23 08:15:49'),
(2, '3', '600', '2024-02-17 11:56:17'),
(3, '11', '400', '2024-02-24 13:17:07'),
(4, '', '1000', '2024-02-19 11:47:51'),
(5, '6', '400', '2024-02-22 13:25:57'),
(6, '12', '1000', '2024-02-22 13:22:20'),
(7, '13', '550', '2024-03-04 08:00:18'),
(8, '5', '1000', '2024-02-26 09:06:46'),
(9, '14', '600', '2024-03-04 07:31:57');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `ID` int(10) NOT NULL,
  `FirstName` varchar(120) DEFAULT NULL,
  `LastName` varchar(120) DEFAULT NULL,
  `MobileNumber` bigint(10) DEFAULT NULL,
  `Email` varchar(200) DEFAULT NULL,
  `Password` varchar(120) DEFAULT NULL,
  `AdminRegdate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`ID`, `FirstName`, `LastName`, `MobileNumber`, `Email`, `Password`, `AdminRegdate`) VALUES
(1, 'PETER', 'MUTINDA', 795538067, 'peterkasamu01@gmail.com', '0dd73696c4aa2eb71e7cd497bd0c8427', '2024-01-31 12:36:28'),
(2, 'dan1', 'muti1', 865443313, 'dan1@gmail.com', '9180b4da3f0c7e80975fad685f7f134e', '2024-01-31 12:37:09'),
(3, 'mwaka', 'jack', 863345671, 'mwaka@gmail.com', '486553dbaa4df50e60d2e4b4af40b5c7', '2024-02-02 08:35:21'),
(5, 'malach', 'osero', 3030303030, 'malach@gmail.com', 'b886089bd15a68d4aca89880a545e27b', '2024-02-02 09:33:00'),
(6, 'jo', 'joy134', 6060606056, 'joy3@gmail.com', 'c6bab591376c2172ca7bd1e0e6132d5a', '2024-02-04 13:01:42'),
(7, 'kk', 'k2', 85453, 'k2@gmail.com', 'a3a12d166f3a88913f94fef28e4a5592', '2024-02-05 08:06:19'),
(8, 'chege', 'dr', 746952207, 'dr@gmail.com', '07c3e880eca21b3bdd0b0cb86b55efb9', '2024-02-06 08:04:14'),
(9, 'tt3', 'jj4', 19216899323, 'rr7@gmail.com', '0dd73696c4aa2eb71e7cd497bd0c8427', '2024-02-07 08:49:22'),
(10, 'jose1', 'mwonge', 906882797, 'jose@gmail.com', 'e088aec58e7e6aae6e1c9919cae0ed85', '2024-02-08 08:50:05'),
(11, 'june', 'jackson', 567890123, 'june@gmail.com', '25a8116b5d1d7c9647fa41b8bedcf221', '2024-02-17 08:27:41'),
(12, 'tinda89', 'uuu', 777777, 'uu@gmail.com', '0dd73696c4aa2eb71e7cd497bd0c8427', '2024-02-19 13:58:00'),
(13, 'daniel', 'mutisya', 701570901, 'muti@gmail.com', '9ad4831d2ead0d43d8a76997f3fe3ada', '2024-02-24 12:51:07'),
(14, 'Eyla', 'otieno', 987654321, 'eyla@gmail.com', '7bb9273184367c78bd43f4ee5ec26e79', '2024-03-02 11:38:05');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbladmin`
--
ALTER TABLE `tbladmin`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblslots`
--
ALTER TABLE `tblslots`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblvehicle`
--
ALTER TABLE `tblvehicle`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblwallet`
--
ALTER TABLE `tblwallet`
  ADD PRIMARY KEY (`WID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbladmin`
--
ALTER TABLE `tbladmin`
  MODIFY `ID` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tblslots`
--
ALTER TABLE `tblslots`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `tblvehicle`
--
ALTER TABLE `tblvehicle`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `tblwallet`
--
ALTER TABLE `tblwallet`
  MODIFY `WID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
